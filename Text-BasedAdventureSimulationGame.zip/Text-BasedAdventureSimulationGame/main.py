#ANA1001_MID-TERM PROJECT
#Tolu David

from random import choice as c
import time
import datetime
import sys
from os import system, name
import termcolor 

#items players use in life()
player_name = input(f"What is your name?\n→\t")
date = a = datetime.datetime.utcnow()
today = (date.strftime("%a" "," " " "%b" " " "%d" "," " " "%Y"))
snackchoices = ''
snacks = []
health_points = 100
healthpoint_indicator = ''
money = 500
netflixshows = [
    'You', 'Inventing Anna', 'Peaky Blinders', 'The Last Kingdom',
    'All of Us Are Dead',
    'The Woman in the House Across the Street from the Girl in the Window',
    'Ozark', 'All Hail King Julien', 'How to Get Away with Murder',
    'The Big Bang Theory', 'Friends', 'House of Cards', 'Narcos', 'Bridgerton'
]
bag = []
backpack = {}
wallet = []
for _ in range(3):
    print(
        "Type your top 3 fave snacks,Press <enter> to keep inputing choices..."
    )
    snacks.append(input(snackchoices))


def clear():
    # for windows
    if name == 'nt':
        _ = system('cls')

    # for mac and linux(here, os.name is 'posix')
    else:
        _ = system('clear')


def life():
    """Defines intro location for both players #game starts here and allows the player choose a character"""
    clear()
    global player_name, snacks, netflixshows, bag, wallet, money
    print(
        f"Welcome to CHOICES! {player_name.title()}, Today is {today}\nSomebody rightly said, ' Life is all about the choices we make.' The decisions we take every single day, whether small or big, impact our life in one way or another and determine how our coming years would unfold. It is simple— the better choices you make today, the better opportunity you have to lead a happy life."
    )
    print("\nPlease choose a character Press:")
    player_choice = input(
        "[1] To play as a Student\n[2] To play as a Working professional\n")
    if player_choice == '1':
        student()
    elif player_choice == '2':
        worker()
    else:
        clear()
        life()


#defining moneybank that allows players make financial decisions
def moneybank():
    if money < 100:
        termcolor.cprint('You are running out of cash...careful', "yellow" )
    elif money < 0:
        termcolor.cprint('You have run out of cash making bad decisions!!!',"red")
        time.sleep(3)
        life()


#defining healthbank that allows players make decisions on their health
def health():
    global health_points, healthpoint_indicator
    if health_points < 25:
        healthpoint_indicator = 'not so good'
        termcolor.cprint(
            f'Your health point is {health_points}. Your health level is {healthpoint_indicator}',"red"
        )
    elif health_points < 75:
        healthpoint_indicator = 'good'
        termcolor.cprint(
            f'Your health point is {health_points}. Your health level is {healthpoint_indicator}',"yellow"
        )
    elif health_points > 75:
        healthpoint_indicator = 'very good'
        termcolor.cprint(
            f'Your health point is {health_points}. Your health level is {healthpoint_indicator}',"green"
        )

    if health_points < 50:  #if healthpoint is below 50, players have a choice to drink human health juice for extra 50 points
        termcolor.cprint(
            f'You need human health juice(HHJ)!',"red"
        )
        time.sleep(2)
        hhj = input(f'Do you wanna?\n[a] Drink HHJ!!\n[b] Do nothing\n')
        if hhj == 'a':
            print(f'Drinking HHJ!! gulp!gulp!! \n' * 3)
            health_points += 50
            health()
        elif hhj == 'b':
            clear()
            pass


#Definition of characters picked by player.
def student():
    """Intro for player 1"""
    clear()
    print(
        f"Hello {player_name.title()} Welcome to life, 'We are the creative force of our life, and through our own decisions rather	than our conditions,if we carefully learn to do certain things, we can accomplish those goals.' —Stephen Covey"
    )
    studenthome()


def worker():
    """Intro for player 2"""
    clear()
    print(
        f"Hello {player_name.title()} Welcome to life,  'We are the creative force of our life, and through our own decisions rather than our conditions, if we carefully learn to do certain things, we can accomplish those goals.' —Stephen Covey"
    )
    workershome()


"""Defintion of locations starts here
Both player charcaters start at home and move through the different relevant locations:Home, school/work,gym,party"""


def studenthome():
    """Defines the home for player 1"""
    clear()
    global health_points, healthpoint_indicator, player_name, snacks, netflixshows, bag, wallet, money
    welcome = [
        "Someone's a lil too comfortable! Don't worry, you are at home!!, You can be a 100% Yourself!!",
        "A lack of motivation can be the biggest obstacle to reaching your goals.\nFor example, rather than sit on the couch in your pajamas all day binge-eating, watching several netlix episodes and waiting for motivation to strike, get dressed and get moving."
    ]
    print(f"{c(welcome)}\n")

    today = input(
        'What do you wanna do today? Press\n[1]To watch a netflix recommended show,\n[2]To school\n[3]Go to the gym\n[4]To go for a party \n'
    )
    if today == '1':
        clear()
        print(
            f"You are now watching {c(netflixshows)}, an interesting show recommended by Netflix, with your fave snack {c(snacks)} in one hand"
        )  #random netflix recommendation + random fave snack
        for i in range(3):
            print("Netflix Time!! " * 3)
            time.sleep(2)
        clear()
        health_points -= 15
        health()
        print(
            f"You look over at the clock and see its been over five hours!. Your eyes hurt from too much screen time, your bladder screams for help!!"
        )
        homeinput = input("Do you wanna \na)Take a break \nb)Keep watching\n")
        if homeinput == 'a':
            print(
                "You have decided to take a break, you put your health first! Great job You!"
            )
            health_points += 0
            health()
            time.sleep(2)
            for i in range(1):
                print("No more Netflix!!")
                time.sleep(3)
            clear()
            studenthome()

        elif homeinput == 'b':
            print("More Netflix time?!!!")
            time.sleep(2)
            for i in range(3):
                time.sleep(2)
                print("Netflix Time!! " * 3)
                health_points -= 10
                health()
            time.sleep(2)
            print(f"That's enough netflix for today!!")
            time.sleep(3)
            clear()
            studenthome()
    elif today == '2':
        school()
        money -= 50
        moneybank()
    elif today == '3':
        gymstu()
        money -= 50
        moneybank()
    elif today == '4':
        partystu()
        money -= 50
        moneybank()
    else:
        clear()
    studenthome()


def workershome():
    """Defines the home for  player 2"""
    clear()
    global health_points, healthpoint_indicator, player_name, snacks, netflixshows, bag, wallet, money, bag
    welcome = [
        "Someone's a lil too comfortable! Don't worry, you are at home!!, You can be a 100% Yourself!!",
        "A lack of motivation can be the biggest obstacle to reaching your goals.\nFor example, rather than sit on the couch in your pajamas all day binge-eating, watching several netlix episodes and waiting for motivation to strike, get dressed and get moving."
    ]
    print(f"{c(welcome)}\n")

    today = input(
        'What do you wanna do today? Press\n[1]To watch a netflix recommended show\n[2]Go to work\n[3]Go to the gym\n[4]Go for a party\n'
    )
    if today == '1':
        clear()
        print(
            f"You are now watching {c(netflixshows)}, an interesting show recommended by Netflix, with your fave snack {c(snacks)} in one hand"
        )  #random netflix recommendation + random fave snack
        for i in range(3):
            print("Netflix Time!! " * 3)
            time.sleep(2)
        clear()
        health_points -= 15
        health()
        print(
            f"You look over at the clock and see its been over five hours!. Your eyes hurt from too much screen time, your bladder screams for help!!"
        )
        homeinput = input("Do you wanna \na)Take a break \nb)Keep watching\n")
        if homeinput == 'a':
            print(
                "You have decided to take a break, you put your health first! Great job You!"
            )
            health_points += 0
            health()
            time.sleep(2)
            for i in range(1):
                print("No more Netflix!!")
                time.sleep(3)
            clear()
            workershome()

        elif homeinput == 'b':
            print("More Netflix time?!!!")
            for i in range(3):
                time.sleep(2)
                print("Netflix Time!! " * 3)
                health_points -= 10
                health()
            time.sleep(2)
            print(f"That's enough netflix for today!!")
            time.sleep(3)
            clear()
            workershome()
    elif today == '2':
        work()
        money -= 50
        moneybank()
    elif today == '3':
        gymworker()
        money -= 50
        moneybank()
    elif today == '4':
        partyworker()
        money -= 50
        moneybank()
    else:
        clear()
    workershome()


def gymstu():
    """Defines the gym location player 1"""
    clear()
    global health_points, healthpoint_indicator, player_name, snacks, netflixshows, bag, wallet, money
    print(
        f"Welcome to the gym {player_name}\nYou don’t need to be extreme, you just need consistency. "
    )
    health()  #prints notification to player on health status
    time.sleep(2)
    print('\nHold on! Is your gym card in your wallet?')
    if 'gym card' in wallet:
        print('Yes')
    elif 'gym card' not in wallet:
        print('No it is not!')
        gymcard = input(
            "Wanna a new one? Enter 'yes' to pay for a new one OR 'no' to go back home\n "
        )
        if gymcard == "yes":
            money -= 50
            moneybank()
            print(
                f"You just paid for a new one at $50, you now have ${money} left "
            )
            wallet.append('gym card')
            time.sleep(3)
        elif gymcard == "no":
            print('Going back home...')
            time.sleep(2)
            clear()
            studenthome()
        else:
            gymstu()
    clear()
    print(
        f"What an unpleasant surprise, you turn away from the cashier's desk and see a frenemy !!"
    )
    gym_input = input(
        'Do you wanna\n[a] Walk up to them and make conversation\n[b] Say Hi from afar and stick to working out\n'
    )
    if gym_input == 'a':
        print("You have decided to engage in small talk , your choice!")
        friend = input(
            f"Frenemy: How are you today {player_name}?\n Type Response\n")
        response = friend
        if "good" in response:
            print("I'm feeling good too!")
            time.sleep(2)
        elif "fine" in response:
            print("I'm feeling good too!")
            time.sleep(2)
        elif "alright" in response:
            print("I'm feeling good too!")
            time.sleep(2)
        else:
            print("I'm sorry to hear that!")
            time.sleep(2)
        print(' chat!!! ' * 3)
        time.sleep(2)
        print(' chat!!! ' * 3)
        time.sleep(2)
        print(' chat!!! ' * 3)
        health_points -= 15 * 3
        health()
        print(
            f"You couldn't work out, you are drained from too much small talk. You need to go home"
        )
        time.sleep(5)
        clear()
        studenthome()

    elif gym_input == 'b':
        clear()
        print("Nice choice!")
        workout_input = input(
            "Do you wanna\n[a] Keep minding your business and do your normal weight lifts\n[b] Show frenemy who's boss\n"
        )
        if workout_input == 'a':
            print(' Weight-lifting!! ' * 3)
            health_points += 15
            health()
            print('Time to go home!')
            time.sleep(2.8)
            clear()
            studenthome()
        elif workout_input == 'b':
            print('You attempt to lift an extremely heavy weight..')
            print(
                "You feel your chest tighten, you realize you must have torn a heart artery,	it is too late to redeem yourself."
            )
            time.sleep(3)
            health_points -= 75
            exitlife()
    else:
        clear()
        gymstu()


def gymworker():
    """Defines the gym location player 2"""
    clear()
    global health_points, healthpoint_indicator, player_name, snacks, netflixshows, bag, wallet, money
    print(
        f"Welcome to the gym {player_name}\nYou don’t need to be extreme, you just need consistency. "
    )
    health()  #prints notification to player on health status
    time.sleep(2)
    print('\nHold on! Is your gym card in your wallet?')
    if 'gym card' in wallet:
        print('Yes')
    elif 'gym card' not in wallet:
        print('No it is not!')
        gymcard = input(
            "Wanna a new one? Enter 'yes' to pay for a new one OR 'no' to go back home\n "
        )
        if gymcard == "yes":
            money -= 50
            moneybank()
            print(
                f"You just paid for a new one at $50, you now have ${money} left "
            )
            wallet.append('gym card')
            time.sleep(3)
        elif gymcard == "no":
            print('Going back home...')
            time.sleep(2)
            clear()
            workershome()
        else:
            gymworker()
    clear()
    print(
        f"What an unpleasant surprise, you turn away from the cashier's desk and see a frenemy !!"
    )
    gym_input = input(
        'Do you wanna?\n[a] Walk up to them and make conversation\n[b] Say Hi from afar and stick to working out\n'
    )
    if gym_input == 'a':
        print("You have decided to engage in small talk , your choice!")
        friend = input(
            f"Frenemy: How are you today {player_name}?\n Type Response\n")
        response = friend
        if "good" in response:
            print("I'm feeling good too!")
            time.sleep(2)
        elif "fine" in response:
            print("I'm feeling good too!")
            time.sleep(2)
        elif "alright" in response:
            print("I'm feeling good too!")
            time.sleep(2)
        else:
            print("I'm sorry to hear that!")
            time.sleep(2)
        print(' chat!!! ' * 3)
        time.sleep(2)
        print(' chat!!! ' * 3)
        time.sleep(2)
        print(' chat!!! ' * 3)
        health_points -= 15 * 3
        health()
        print(
            f"You couldn't work out, you are drained from too much small talk. You need to go home"
        )
        time.sleep(5)
        clear()
        workershome()

    elif gym_input == 'b':
        clear()
        print("Nice choice!")
        workout_input = input(
            "Do you wanna\n[a] Keep minding your business and do your normal weight lifts\n[b] Show frenemy who's boss\n"
        )
        if workout_input == 'a':
            print(' Weight-lifting!! ' * 3)
            health_points += 15
            health()
            print('Time to go home!')
            time.sleep(2.8)
            clear()
            workershome()
        elif workout_input == 'b':
            print('You attempt to lift an extremely heavy weight..')
            print(
                "You feel your chest tighten, you realize you must have torn a heart artery,	it is too late to redeem yourself."
            )
            time.sleep(3)
            health_points -= 75
            exitlife()
    else:
        gymworker()


def school():
    """Defines the school location player 1"""
    clear()
    global health_points, healthpoint_indicator, player_name, snacks, netflixshows, bag, wallet, money, backpack
    print(backpack)
    print('Before you head in...')
    checkbag = input(
        f"Do you wanna\n[a]Check if all study materials are in your schoolbag\n[b]Ignore gut feeling, you have everything\n"
    )
    if checkbag == 'a':
        print("Checking Bag..!")
        time.sleep(2)
        if 'studymaterials' in backpack:
            print('You have your study materials')
        elif 'studymaterials' not in backpack:
            print(
                "You don't have your study materials.....You had to buy new study materials\n"
            )
            money -= 50
            moneybank()
            print(f"You just spent $50, you now have ${money} left")
            backpack['studymaterials'] = [
                'pencils', 'pen', 'textbooks', 'notebooks'
            ]  #a dictionary holds school items in 'study materials'
            print(f"look at the items in your backpack:")
            print(backpack['studymaterials'], sep=",")
        print(f"Hello {player_name} Welcome to school!!")
        print('\tschool time...\n\t' * 3)
        time.sleep(2)
        print('\tschool time...\n\t' * 3)
        time.sleep(2)
        leaveschool = input(
            "You're done with school for today. Do you wanna?\n[a]Go home\n[b]Go to a party\n"
        )
        if leaveschool == 'a':
            studenthome()
        elif leaveschool == 'b':
            partystu()
        else:
            school()
    elif checkbag == 'b':
        print(f"Hello {player_name} Welcome to school!!")
        print(
            "It is test day! and no one told you??, you need your study materials, I hope you have them."
        )
        print('Checking if your have your study materials....\n' +
              'Checking if your have your study materials....\n')
        time.sleep(3)
        if any(backpack):
            print('Test time!!')
            print('Great job YOU! Come back next week for your test scores!')
            time.sleep(3)
        else:  #this only runs when option is chosen from the start at school()
            print(
                "You don't have your study materials. You cannot take the test. You have been summoned to the teacher's desk, your teacher asks you why you have refused to take the test."
            )
            test_input = input(
                "What do you wanna do?\n[a]Yell at the teacher,it is not your fault!\n[B]Politely ask for extension\n"
            )
            if test_input == 'a':
                print(
                    'You are expelled for gross insurbodination. Go back Home..'
                )
                print('We are our choices!')
                time.sleep(3)
                clear()
                studenthome(
                )  #students still get a second chance at life even if they don't act right in school
            elif test_input == 'b':
                print(
                    'You have been granted permission to take the test another day!'
                )
                time.sleep(3)
                clear()
            studenthome()
    else:
        school()


def work():
    """Defines the work location player 2"""
    global health_points, healthpoint_indicator, player_name, snacks, netflixshows, bag, wallet, money
    clear()
    spend = input('Do you wanna\n[a]Drive\n[b]Ride the bus\n')
    if spend == 'a':
        money -= 223
        moneybank()
        print(f'You just spent $223 on gas, money left is ${money} ')
        print('Car honks!\nzroom! vroom! \n' * 3)
        time.sleep(2)
        print(
            'You get on the road and there is traffic due to a dog taking control of tractor.'
        )
        for i in range(3):
            time.sleep(2)
            print('Waiting...\n')
        print(
            f"After waiting for a long time for traffic to finally clear up ")
        print(
            "You get to work, your Boss is mad, you are late! you try to explain things to your boss but it falls to deaf ears!"
        )
        print(
            f"The next thing you hear is a loud yell '{player_name}, you are fired!!' "
        )
        print('We are our choices!')
        time.sleep(5)
        exitlife()  #you lose your job, you lose your life

    elif spend == 'b':
        money -= .98
        print(
            'Mass transit can be very unreliable! unfortunately, there has been some changes in the bus schedule.'
        )
        time.sleep(2)
        masstransit = input(
            f"Do you wanna?\n[a]Wait for the bus\n[b]Order a taxi\n")
        if masstransit == 'a':
            for i in range(3):
                time.sleep(2)
                print('Waiting...\n')
            print(
                "You look over at your watch, it seems you have been waiting for over an hour!."
            )
            print(f"Just when you decide to leave, you see the bus arrive\n.")
            print(
                "You get to work, your Boss is mad, you are late! you try to explain things to your boss but it falls to deaf ears!"
            )
            print(
                f"The next thing you hear is a loud yell '{player_name}, you are fired!!' "
            )
            print('We are our choices!')
            time.sleep(5)
            exitlife()

        elif masstransit == 'b':
            for i in range(3):
                time.sleep(2)
                print('Waiting for taxi...\n')
            print("Your taxi has arrived!")
            print(
                'You get on the road and there is traffic due to a dog taking control of tractor.'
            )
            for i in range(3):
                time.sleep(2)
                print('Waiting...\n')
            print(
                f"After waiting for a long time for traffic to finally clear up "
            )
            print(
                "You get to work, your Boss is mad, you are late! you try to explain things to your boss but it falls to deaf ears!"
            )
            print(
                f"The next thing you hear is a loud yell '{player_name}, you are fired!!' "
            )
            print('We are our choices!')
            time.sleep(5)
            clear()
            exitlife()
    else:
        clear()
        work()


def partystu():
    """Defines the party location player 1(student)"""
    clear()
    global health_points, healthpoint_indicator, player_name, snacks, netflixshows, bag, wallet, money
    print('Party Time!!')
    bouncer = input(
        f"Bouncer: Hello {player_name} Do you have some ID?\n Type Response 'yes' or 'no'\n"
    )
    if "yes" in bouncer:
        print('You are now checking for your ID...\n' * 3)
        if "ID" in bag:  #runs when you come back to party a second time and you have ID.
            for _ in range(
                    24
            ):  #You can party for 24 hours(if you have enough money and energy/healthpoints)
                drinks = input('Wanna a drink?\n[1]Yes\n[2]No\n')
                if drinks == '1':
                    money -= 5
                    health_points -= 10
                    moneybank()
                    health()
                elif drinks == '2':
                    money -= 5
                    health_points -= 10
                    moneybank()
                    health()
                else:
                    clear()
                    partystu()
            print("That's enough partying for today")
            time.sleep(3)
            studenthome()
        elif "ID" not in bag:
            print(
                "You don't have ID,I'm sorry to you can't come in!"
            )  #you keep going back to the door 'party()'until you say 'no'
            time.sleep(3)
            partystu()
    elif "no" in bouncer:
        clear()
        chance = input('Do you wanna?\n[a]Go home & grab ID or\
        \n[b]Fight the bouncer, after all you look old enough\n')
        if chance == 'a':
            print('on your way home!')
            time.sleep(3)
            bag.append("ID")
            studenthome()
        elif chance == 'b':
            health_points -= 100
            print(
                'Parties are a risk. They can be a blast. Or they can be a disaster.'
            )
            time.sleep(3)
            health()
            exitlife()
    else:
        clear()
        partystu()


def partyworker():
    """Defines the party location player 2"""
    clear()
    global health_points, healthpoint_indicator, player_name, snacks, netflixshows, bag, wallet, money
    print('Party Time!!')
    bouncer = input(
        f"Bouncer: Hello {player_name} Do you have some ID?\n Type Response 'yes' or 'no'\n"
    )
    if "yes" in bouncer:
        print('You are now checking for your ID...\n' * 3)
        if "ID" in bag:  #runs when you come back to party a second time and you have ID.
            for _ in range(
                    24
            ):  #You can party for 24 hours(if you have enough money and energy/healthpoints)
                drinks = input('Wanna a drink?\n[1]Yes\n[2]No\n')
                if drinks == '1':
                    money -= 5
                    health_points -= 10
                    moneybank()
                    health()
                elif drinks == '2':
                    money -= 5
                    health_points -= 10
                    moneybank()
                    health()
                else:
                    clear()
                    partyworker()
            print("That's enough partying for today")
            time.sleep(3)
            studenthome()
        elif "ID" not in bag:
            print(
                "You don't have ID,I'm sorry to you can't come in!"
            )  #you keep going back to the door 'party()'until you say the truth 'no'
            time.sleep(3)
            partyworker()
    elif "no" in bouncer:
        clear()
        chance = input('Do you wanna?\n[a]Go home & grab ID or\
        \n[b]Fight the bouncer, after all you look old enough\n')
        if chance == 'a':
            print('on your way home!')
            time.sleep(3)
            bag.append("ID")
            workershome()
        elif chance == 'b':
            health_points -= 100
            print(
                'Parties are a risk. They can be a blast. Or they can be a disaster.'
            )
            time.sleep(3)
            health()
            exitlife()
    else:
        clear()
        partyworker()


def exitlife():
    """Defines the final existence of players before death or to quit playing the game"""
    play_again = input(
        'Want a second chance at life?,\nType "yes" to play again or "no" to end game\n'
    )
    if play_again == 'yes':
        print('ha! Welcome back')
        time.sleep(2)
        life()
    elif play_again == 'no':
        clear()
        sys.exit(
            f"We are our choices!, I hope your friends say nice things at your funeral,your ${money} goes to charity. Thanks!"
        )  #shuts off python
    else:
        exitlife()


life()
